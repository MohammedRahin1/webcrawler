#include <stdio.h>
#include <curl/curl.h>
#include <gumbo.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

//Thread Arg Object containing the url property to pass into ProcessUrl Method
typedef struct {
	char* url;
} ThreadArg;

//Structure of dynamic Array
typedef struct {
	char** data;
	size_t size;
	size_t capacity;
} DynamicArray;

/// <summary>
/// Initializes dynamic array by:
/// 1.) setting the size to 0
/// 2.) setting capacity to 8
/// 3.) allocates memory of data char[] by multiplying capacity property value and size of char pointer type (8 * sizeof(char*))
/// </summary>
/// <param name="array"></param>
void dynamic_array_init(DynamicArray* array) {
	array->size = 0;
	array->capacity = 8;
	array->data = malloc(array->capacity * sizeof(char*));
}

/// <summary>
/// Appends item to Dynamic Array Pointer Object by:
/// 1.) checking size and capacity values and if they are equal, double the 'capacity' property value and reallocate the memory of data char[] to be bigger.
/// 2.) otherwise continue to setting the data char[] value index to the item e.g link and increase the size property value up one to move to the next data char[] index.
/// 3.) this appends to each index of data property until it reaches full and then doubles the size to continue so there aren't memory leaks
/// </summary>
/// <param name="array"></param>
/// <param name="item"></param>
void dynamic_array_append(DynamicArray* array, const char* item) {
	if (array->size == array->capacity) {
		array->capacity *= 2;
		void* new_data = realloc(array->data, array->capacity * sizeof(char*));
		if (new_data == NULL) {
			printf("failed to allocate memory while expanding dynamic array.\n");
			return;
		}
		array->data = new_data;
	}
	array->data[array->size] = _strdup(item);
	array->size++;
}

/// <summary>
/// NOTE: free method is a built in method that Resets the size of a variable and deAllocates memory
/// Frees Up Memory of Dynamic array object by:
/// 1.) Going through each index of data property 
/// 2.) Calling the free method passing in the data property index
/// 3.) then calls free again on the data property itself
/// </summary>
/// <param name="array"></param>
void dynamic_array_free(DynamicArray* array) {
	for (size_t i = 0; i < array->size; i++) {
		free(array->data[i]);
	}
	free(array->data);
}

/// <summary>
/// Does Memory Allocation for content found in downloaded page
/// </summary>
/// <param name="contents"></param>
/// <param name="size"></param>
/// <param name="nmemb"></param>
/// <param name="userp"></param>
/// <returns></returns>
size_t write_callback(void* contents, size_t size, size_t nmemb, void* userp) {
	size_t realsize = size * nmemb;
	char** response = (char**)userp;
	char* new_response = realloc(*response, strlen(*response) + realsize + 1);
	if (new_response == NULL) {
		printf("Failed to allocate memory for the recieved data.\n");
		return 0;
	}
	*response = new_response;
	size_t current_length = strlen(*response);
	strncat_s(*response, current_length + realsize + 1, contents, realsize);
	return realsize;
}

/// <summary>
/// Downloads the page given the Url passed in the parameter
/// 1.) Initializes easy curl method which manages the curl session
///     * sets the curl options to the session by passing the url to download
///     * Sets the curl write function to called to handle downloaded page data
///     * Sets the pointer variable where the downloaded page will be stored into; e.g response var
/// 2.) Performs the actual download using curl_easy_perform 
/// 3.) handles errors if not successful
/// 4.) returns response data
/// </summary>
/// <param name="url"></param>
/// <returns></returns>
char* download_page(const char* url) {
	CURL* curl = curl_easy_init();
	CURLcode res;
	char* response = calloc(1, sizeof(char));

	//if curl session exists, set curl session options
	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

		//Starts Download Process
		res = curl_easy_perform(curl);
		//checks to see if session download was performed successfully
		if (res != CURLE_OK) {
			printf("Failed to download the web page: %s\n", curl_easy_strerror(res));
			free(response);
			response = NULL;
		}
		//cleans curl session
		curl_easy_cleanup(curl);
	}

	return response;
}

/// <summary>
/// 1.) Checks to see if the type of the node passed in is Enum Gumbo Node Element
/// 2.) Sets a Pointer vairable named href and checks to see if:
///     * The html parsed element node is an a or 'anchor' tag. link tag
///     * AND contains 'href' as part of the string
/// 3.) it then appends the link into the data structure object if the above is true
///     by calling the dynamic_array_append method with the link object and href object value property
/// 4.) it then checks for children nodes as well of the current gumbo node and calls a recursive function repeating the above steps
/// </summary>
/// <param name="node"></param>
/// <param name="links"></param>
void extract_links(GumboNode* node, DynamicArray* links) {
	if (node->type != GUMBO_NODE_ELEMENT) {
		return;
	}

	GumboAttribute* href;
	if (node->v.element.tag == GUMBO_TAG_A &&
		(href = gumbo_get_attribute(&node->v.element.attributes, "href"))) {

		dynamic_array_append(links, href->value);
	}

	GumboVector* children = &node->v.element.children;
	for (size_t i = 0; i < children->length; ++i) {
		extract_links(children->data[i], links);
	}
}


/// <summary>
/// 1.) Processes The arg parameter as a ThreadArg Struct type
/// 2.) then takes the value of the struct object property 'url' and assign
///     it to a new const char url variable 
/// 3.) passes the url into the download_method and extracts the content into page_content var
/// 4.) handles if page had no content, else pass page_content into gumbo method to parse page
/// 5.) initialize links DynamicArray Object by calling dynamic_array_init
/// 6.) pass root of parsed page_content 'output' and dynamic array into extract_link method
/// 7.) prints links found and file prints into outfile append mode; also handles file opening errors
/// 8.) calls dynamic_array_free method to clean dynamic array
/// 9.) destroy gumbo parsed page content 'output' variable
/// 10.) free page_content var
/// 11.) closes output file
/// 12.) return NULL
/// GO TO DOWNLOAD_PAGE -> DYNAMIC_ARRAY_INIT -> EXTRACT_LINKS -> DYNAMIC_ARRAY_FREE METHODS IN ORDER TO FOLLOW CONTINUED FLOW
/// </summary>
/// <param name="url"></param>
void *process_url(void* arg) {

	ThreadArg* thread_arg = (ThreadArg*)arg;
	const char* url = thread_arg->url;

	printf("Crawling: %s\n", url);

	char* page_content = download_page(url);
	if (page_content == NULL) {
		printf("Failed to download the web page: %s\n", url);
		return NULL;
	}

	GumboOutput* output = gumbo_parse(page_content);
	DynamicArray links;
	dynamic_array_init(&links);

	extract_links(output->root, &links);
	FILE* output_file;
	errno_t err = fopen_s(&output_file, "output.txt", "a");
	if (err != 0 || output_file == NULL) {
		printf("Failed to open output file for writing.\n");
		dynamic_array_free(&links);
		gumbo_destroy_output(&kGumboDefaultOptions, output);
		free(page_content);
		return NULL;
	}

	for (size_t i = 0; i < links.size; ++i) {
		printf("  Found link: %s\n", links.data[i]);
		fprintf(output_file, "%s\n", links.data[i]);
	}
	//closes output file and cleans variables
	fclose(output_file);
	dynamic_array_free(&links);
	gumbo_destroy_output(&kGumboDefaultOptions, output);
	free(page_content);
	return NULL;
}

/// <summary>
/// 1.) Initializes the Global curl object
/// 2.)Open and Read Urls From Input file to see if it exists
/// 3.) counts the number of lines if it does exist and sets the count to url_count var
/// 4.)it allocates the memory necessary for the threads object and threadArgs object.
///     *uses the url_count along with the size of the object types to allocate memory properly
/// 5.)Resets File Reading Postion back to the top of the file
/// 6.)It Then Creates Thread Objects and ThreadArg Objects for each line in the file.
///  * each line gets a thread, and each thread contains a threadArg Object
///  * each ThreadArg Object Contains the Url char[] or 'string' to use for processUrl Method
/// 7.) Creates a thread Process using the pthread_create Method with the following parameter:
///     * Threads[index] as the thread object to use
///     * The ProcessUrl Method as the method to run on the Thread
///     * ThreadArg as the Parameter to Pass into ProcessUrl Method 
///     *NULL  is for the process attr which isnt needed
/// 8.) Then Closes The file when completed reading and creating threads
/// 9.) For loop waits for all threads to complete then frees the process memories
/// 10.) cleans Global curl usage
/// 
/// GO TO PROCESS_URL FOR NEXT FLOW STEPS
/// </summary>
/// <returns></returns>
int main() {
	// Initialize the curl library
	curl_global_init(CURL_GLOBAL_DEFAULT);
	FILE* input_file;
	// Read URLs from input file
	errno_t err = fopen_s(&input_file, "input.txt", "r");
	if (err != 0 || input_file == NULL) {
		printf("Failed to open input file: %s\n", "input.txt");
		return 1;
	}

	// Count the number of URLs in the file
	int url_count = 0;
	char line[1024];
	while (fgets(line, sizeof(line), input_file) != NULL) {
		url_count++;
	}

	// Allocate memory for threads and thread_args arrays
	pthread_t* threads = malloc(url_count * sizeof(pthread_t));
	ThreadArg* thread_args = (ThreadArg*)malloc(url_count * sizeof(ThreadArg));
	if (thread_args == NULL) {
		printf("Failed to allocate memory for thread arguments.\n");
		return 1;
	}

	// Rewind the file to the beginning
	fseek(input_file, 0, SEEK_SET);

	// Create a thread for each URL and process it concurrently
	int thread_count = 0;
	char url[1024];
	while (fgets(url, sizeof(url), input_file)) {
		// Remove newline character at the end of the line
		//replaces index of \n with a \0
		size_t url_length = strcspn(url, "\n");
		url[url_length] = '\0';
		//allocates memory for string and duplicates the arg passed in.
		//Returns a pointer to the newly allocated string, needs memory freed after usage
		thread_args[thread_count].url = (char*)malloc((url_length + 1) * sizeof(char));
		strncpy_s(thread_args[thread_count].url, url_length + 1, url, url_length);
		pthread_create(&threads[thread_count], NULL, (void* (*)(void*))process_url, &thread_args[thread_count]);  // <- process_url method call
		thread_count++;
	}

	// Close the input file
	fclose(input_file);

	// Wait for all threads to complete using pthread, then cleans all thread object sessions
	for (int i = 0; i < thread_count; i++) {
		pthread_join(threads[i], NULL);
		free(thread_args[i].url);
	}

	// Clean up the curl library after storing in dynamic array
	curl_global_cleanup();

	return 0;
}
